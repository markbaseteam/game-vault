> [!warning] MVP, copied from the previous project


Each wound can affect the target's ability to move, shot accuracy, movement speed, etc. The wound can also affect the target's ability to use weapons or perform certain actions depending on where it hits.

| Wound     | Effect              |
| --------- | ------------------- |
| Leg wound | -20% movement speed |
| Arm wound | -25% accuracy       |
| Headshot  | +50% damage dealt   |

Values do not stack.

---
## Accuracy modifiers with wounds

> [!warning] Review and fix this

| Wound         | Accuracy modifier |
| ------------- | ----------------- |
| Leg wound     | Accuracy * 0.85   |
| Arm wound     | Accuracy * 0.6    |
| Forearm wound | Accuracy * 0.45   |
| Hand wound    | Accuracy * 0.25   | 
