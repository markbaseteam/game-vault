> [!warning] This is copied from the last project, to fix

Accuracy will be calculated using this formula:
![[accuracy formula.png]]

### How to understand this formula

- 100 - base hit chance, 100%
- Between first brackets - distance from enemy relative to max distance, which is dynamic and dependent on weapon attachments
- Between the second brackets - _light_intensity_ is doubled to nerf accuracy when it's dark, then multiply by 100, because the intensity is in the range of 0-1, then divide by 200 to get a maximum value of 0.5. In the end, add _0.5_, because the result will be in the range of 0-0.5, and we still need to focus on distance. So now the minimum value will be equal to 0.5.

### How the accuracy system works

It's based on RNG (random number generator). For example, if accuracy is equal to 0.75 get a random number between 0-100. If the drawn number is in the range of 75-100 then miss a shot.

[[Wound system#Accuracy modifiers with wounds]]

---
## Distance Damage

The farther the target is from the shooter, the less damage it will deal. A close-up shot does full damage, but a long-range shot does only half or less.

| Distance | Damage modifier |
| -------- | --------------- |
| Short    | 100%            |
| Medium   | 75%             |
| Long     | 50%             |
