#note #quote

[nietzsche.pdf (lo13.wroc.pl)](https://www.lo13.wroc.pl/dl/nietzsche.pdf)
![[Kim_jest_nadczlowiek.pdf]]