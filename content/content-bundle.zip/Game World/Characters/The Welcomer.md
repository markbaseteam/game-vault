## Character information
**Name:** 
**Age:** 
**Faction:** 

## Behavior / Purpose
This character will stand near the first location and tell a player the [[Optional welcome dialogue]]