## Stolen from the old project
In an unspecified year, but between 2003 and 2012, the world's oil limits began to run out. This led to wars between countries that started at different times - so it's hard to pinpoint the start year. Wars were primarily aimed at obtaining oil, but, as it turned out later, they irreversibly destroyed entire cities and countries.

Then cities began to be bombed, and finally, in 2017, nuclear weapons were used, but only in certain places. Cities and people began to turn to dust, and in places untouched by radiation, people began to adapt using solar panels.

Solar panels were used to power greenhouses, places for livestock and groundwater filters for basic needs.

## New storyline draft

