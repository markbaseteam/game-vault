## Character information
**Name:** 
**Age:** 
**Faction:** 

